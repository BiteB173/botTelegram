#====================(DESCRIÇÃO)======================
#BIBLIOTECA(TELEBOT)
#FEITO COM S2 :-) PELO @IAMBITE
#BOT SIMPLES PARA MOSTRAR LINK EM SEU GRUPO.

#====================================================

import telebot

#================(TOKEN DO SEU BOT)===================

TOKEN_BOT = "COLOQUE-AQUI-O-TOKEN-DO-SEU-BOT"
bot = telebot.TeleBot(TOKEN_BOT)

#==================(TABELA 1)=========================

@bot.message_handler(commands=["grupo"])
def grupo(menssagem):
    bot.send_message(menssagem.chat.id, "Este é o link do grupo https://t.me/grupodobite")

@bot.message_handler(commands=["canal"])
def grupo(menssagem):
    bot.send_message(menssagem.chat.id, "Este é o link do canal https://t.me/repobite")

@bot.message_handler(commands=["privado"])
def grupo(menssagem):
    bot.send_message(menssagem.chat.id, "Este é o link do privado https://t.me/iambite")

#==================(TABELA2 OPCOES)====================

@bot.message_handler(commands=["opcao1"])
def opcao1(mensagem):
    bot.send_message(mensagem.chat.id, "Este é o link do grupo https://t.me/grupodobite")

@bot.message_handler(commands=["opcao2"])
def opcao2(message):
    bot.send_message(message.chat.id, "Este é o link do canal https://t.me/repobite ")

@bot.message_handler(commands=["opcao3"])
def opcao3(message):
    bot.send_message(message.chat.id, "Este é o link do privado https://t.me/iambite ")

#=====================(VERIFICAR)=======================

def verificar(menssagem):
    return True

#=====================(RESPONDER)=======================

@bot.message_handler(func=verificar)
def responder(mensagem):
    texto = """
    Escolha uma das opcoes para continuar (Clique no item):
    /opcao1 Link do grupo do Bite.
    /opcao2 Link do Repositorio do Bite (Canal)
    /opcao3 Link do Privado do Bite.
Se vc mandar qualquer outra coisa não irar acontecer nada, clique em alguma opc!"""
    bot.reply_to(mensagem, texto)

bot.polling()